import PostList from "./posts/[page]/page";

export default async function Home() {

 
  return (
    <>
        <PostList />
    </>
  )
}
